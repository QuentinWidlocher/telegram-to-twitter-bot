'use strict';

Object.defineProperty(exports, '__esModule', { value: true });

var twitterApiV2 = require('twitter-api-v2');
var DB = require('aws-sdk/clients/dynamodb');
var TelegramBot = require('node-telegram-bot-api');

function _interopDefault (e) { return e && e.__esModule ? e : { 'default': e }; }

var DB__default = /*#__PURE__*/_interopDefault(DB);
var TelegramBot__default = /*#__PURE__*/_interopDefault(TelegramBot);

const baseClient = new twitterApiV2.TwitterApi({
  clientId: process.env.TWITTER_CLIENT_ID,
  clientSecret: process.env.TWITTER_CLIENT_SECRET
});
async function startLogin(from, client = baseClient) {
  let url = new URL(process.env.REDIRECT_URL);
  url.searchParams.set("userId", String(from.userId));
  url.searchParams.set("chatId", String(from.chatId));
  const authLink = await client.generateOAuth2AuthLink(url.toString(), {
    scope: ["tweet.read", "tweet.write", "users.read", "offline.access"]
  });
  return authLink;
}
async function getClientFromLoginCode(code, codeVerifier, from, client = baseClient) {
  let redirectUri = new URL(process.env.REDIRECT_URL);
  redirectUri.searchParams.set("userId", String(from.userId));
  redirectUri.searchParams.set("chatId", String(from.chatId));
  return client.loginWithOAuth2({
    code,
    codeVerifier,
    redirectUri: redirectUri.toString()
  });
}

const db = new DB__default["default"]({
  region: "us-east-1",
  credentials: {
    accessKeyId: process.env.ACCESS_KEY_ID,
    secretAccessKey: process.env.SECRET_ACCESS_KEY
  }
});
async function update(userId, data) {
  let existing = await retreive(userId);
  console.log("existing", existing);
  let newData = { ...existing,
    ...data,
    credentials: { ...existing.credentials,
      ...data.credentials
    }
  };
  console.log("newData", newData);
  await store(userId, newData);
}
async function store(userId, data) {
  await db.putItem({
    TableName: "telegram-to-twitter-bot",
    Item: {
      userId: {
        S: String(userId)
      },
      data: {
        S: JSON.stringify(data)
      }
    }
  }).promise();
}
async function retreive(userId) {
  console.log("retreive", userId, db);
  return db.getItem({
    TableName: "telegram-to-twitter-bot",
    Key: {
      userId: {
        S: String(userId)
      }
    }
  }).promise().then(data => {
    console.log("retreived", data);
    return JSON.parse(data.$response.data?.Item?.data?.S ?? "{}");
  }).catch(e => {
    console.error("retreive error", e);
    return {};
  });
}

async function app(body, bot) {
  console.log("body", body);
  return new Promise(resolve => {
    bot.on('text', msg => {// console.log("msg", msg);
      // await bot.sendMessage(msg.chat.id, `You just said ${msg.text}`);
    });
    bot.onText(/\/start$/m, async msg => {
      console.log("/start", msg);

      if (!msg.from?.id) {
        resolve();
        return;
      }

      let {
        url,
        codeVerifier
      } = await startLogin({
        userId: msg.from.id,
        chatId: msg.chat.id
      });
      console.log("url", url);
      await update(msg.from.id, {
        credentials: {
          codeVerifier
        }
      });
      console.log("updated db");
      await await bot.sendMessage(msg.chat.id, `
Hey ! Welcome to this bot 👋

You can use it to bind a Twitter account to a Telegram channel.
Each time you send a post in the channel, it will be sent to your Twitter account.

To start, you'll need to connect your Twitter account.
Click the link below to get started. You'll be redirected to this bot and asked to press start again.
    `, {
        reply_markup: {
          inline_keyboard: [[{
            text: "Connect this bot to Twitter",
            url
          }]]
        }
      });
      resolve();
    });
    bot.onText(/^\/link\s(.*)/m, async (msg, match) => {
      console.log("/link <channel>", msg, match);

      if (!msg.from?.id) {
        resolve();
        return;
      }

      const channelName = (match ?? [])[1];
      console.log("channelName", channelName);

      if (!channelName) {
        await bot.sendMessage(msg.chat.id, `
You need to provide a channel name.
Call the command \`/link @<channel-name>\` where @channel-name is the name of the Telegram channel you want to link.
      `);
        resolve();
        return;
      }

      let {
        credentials
      } = await retreive(msg.from.id);

      if (!credentials?.refreshToken) {
        await bot.sendMessage(msg.chat.id, `
You need to connect your Twitter account first.
Call the command \`/start\` to start the process.
      `);
        resolve();
        return;
      }

      await update(msg.from.id, {
        channelId: channelName
      });
      await bot.sendMessage(msg.chat.id, `
You've just linked your Twitter account to this bot.
Now, you can add this bot to you channel, and when you send posts, they will be synced with your Twitter account.
    `);
      resolve();
    });
    bot.processUpdate(body);
  });
}

const token = process.env.TELEGRAM_BOT_TOKEN;
async function handler(event) {
  console.log("event", event);
  const bot = new TelegramBot__default["default"](token);

  if (event.rawPath == '/authorize' && event.queryStringParameters.code && event.queryStringParameters.userId && event.queryStringParameters.chatId) {
    const code = event.queryStringParameters.code;
    const userId = event.queryStringParameters.userId;
    const chatId = event.queryStringParameters.chatId;
    const redirect = {
      statusCode: 302,
      headers: {
        Location: 'tg://resolve?domain=TgToTwitterBot'
      }
    };

    if (!code) {
      let {
        url,
        codeVerifier
      } = await startLogin({
        userId,
        chatId
      });
      await update(userId, {
        credentials: {
          codeVerifier
        }
      });
      await bot.sendMessage(chatId, `
You need to provide a code.
You can get it by clicking the link below.
      `, {
        reply_markup: {
          inline_keyboard: [[{
            text: "Connect this bot to Twitter",
            url
          }]]
        }
      });
      return redirect;
    }

    let {
      credentials
    } = await retreive(userId);

    try {
      let authentication = await getClientFromLoginCode(code, credentials?.codeVerifier ?? '', {
        userId,
        chatId
      });
      await update(userId, {
        credentials: {
          refreshToken: authentication.refreshToken
        }
      });
      await bot.sendMessage(chatId, `
You've just connected your Twitter account to this bot.
Now, call the command \`/link @<channel-name>\` where @channel-name is the name of the Telegram channel you want to link.
      `);
    } catch (error) {
      console.log("error", error);
      await bot.sendMessage(chatId, `
An error occured while connecting your Twitter account to this bot.
Please try again.
      `);
    }

    return redirect;
  }

  try {
    await app(JSON.parse(event.body), bot);
    return {
      statusCode: 200,
      body: JSON.stringify(event)
    };
  } catch (e) {
    console.error(e);
    return {
      statusCode: 200,
      body: JSON.stringify(e)
    };
  }
}

exports.handler = handler;
